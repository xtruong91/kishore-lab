// system/greetings.c
 #include <xinu.h>

 void greetings(void) {
     kprintf("Hello World! This is [Saimonish], [stungutu], Year: [Senior], Semester: [8]\n\n");
 }
