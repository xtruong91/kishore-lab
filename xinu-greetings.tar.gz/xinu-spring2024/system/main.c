// system/main.c

#include <xinu.h>

process	main(void)
{
	kprintf("Test process executing main(): PID = %d\n", getpid());
	return OK;

}
